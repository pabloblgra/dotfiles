# Unicode stress tests

Please be careful editing, this contains carefully crafted characters.

Two byte character: spatiëring

Combining character: spatiëring

Three byte character: 书こんにちは

Four byte character: 𐌀‮𐌁‮𐌂‮𐌃‮𐌄‮𐌅‮𐌆‮𐌇‮𐌈‬

Right-to-left: مرحبا

Emoticons: 🔊 😍 💜 1️⃣

right-to-left mark: hello באמת!‏


Zalgo: ǫ̛̖̱̗̝͈̋͒͋̏ͥͫ̒̆ͩ̏͌̾͊͐ͪ̾̚


fn some_function() {
    assert!($TEST_STATUS);
}

fn main() {
    some_function();
}

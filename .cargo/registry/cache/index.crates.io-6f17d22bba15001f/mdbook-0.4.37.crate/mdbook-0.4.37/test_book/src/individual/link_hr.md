# Links and Horizontal Rule

This is followed by a Horizontal rule

---

And this is preceded by a horizontal rule.

[This](www.rust-lang.org) should link to rust-lang website  
[So should this][rl].  
**[This][rl]** is a strong link.  
_[This][rl]_ is italic.  
**_[This][rl]_** is both.

[rl]: www.rust-lang.org

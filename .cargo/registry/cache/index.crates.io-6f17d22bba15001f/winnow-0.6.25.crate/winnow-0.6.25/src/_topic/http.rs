//! # HTTP
//!
//! ```rust
#![doc = include_str!("../../examples/http/parser.rs")]
//! ```

// Take a look at the license at the top of the repository in the LICENSE file.

use crate::ApplicationFlags;

impl Default for ApplicationFlags {
    fn default() -> Self {
        Self::empty()
    }
}

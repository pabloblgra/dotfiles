# lyon::geom

2D geometric primitives on top of [euclid](https://docs.rs/euclid/).

<p align="center">
  <a href="https://crates.io/crates/lyon_geom">
      <img src="https://img.shields.io/crates/v/lyon_geom.svg" alt="crates.io">
  </a>
  <a href="https://docs.rs/lyon_geom">
      <img src="https://docs.rs/lyon_geom/badge.svg" alt="documentation">
  </a>
</p>

`lyon_geom` can be used as a standalone crate or as part of [lyon](https://docs.rs/lyon/) via the `lyon::geom` module.

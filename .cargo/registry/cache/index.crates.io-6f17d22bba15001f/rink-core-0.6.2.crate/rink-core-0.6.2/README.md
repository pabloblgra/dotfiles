# Rink Core

Rink Core is the library that implements most of the special language
and calculations in [Rink](https://crates.io/crates/rink). It's mainly
intended to be used in projects that are exposing an end user interface
to Rink, e.g. a discord bot or a mobile app.

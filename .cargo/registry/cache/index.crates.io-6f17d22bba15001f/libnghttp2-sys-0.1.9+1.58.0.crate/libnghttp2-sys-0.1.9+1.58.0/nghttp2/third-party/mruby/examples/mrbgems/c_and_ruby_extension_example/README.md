# C and Ruby Extension Example

This is an example gem which implements a C and Ruby extension.

module CRubyExtension
  def CRubyExtension.ruby_method
    puts "#{self}: A Ruby Extension"
  end
end

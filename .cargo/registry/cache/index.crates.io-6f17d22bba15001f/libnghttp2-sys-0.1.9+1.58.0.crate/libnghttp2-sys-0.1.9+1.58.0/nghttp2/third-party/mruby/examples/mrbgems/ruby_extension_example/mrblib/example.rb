class RubyExtension
  def RubyExtension.ruby_method
    puts "#{self}: A Ruby Extension"
  end
end

#include <mruby.h>

void
mrb_cdata_extension_example_gem_test(mrb_state *mrb)
{
  /* test initializer in C */
}

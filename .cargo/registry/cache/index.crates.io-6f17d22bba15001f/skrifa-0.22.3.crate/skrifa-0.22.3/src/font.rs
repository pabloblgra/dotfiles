//! Basic representation of an in-memory font resource.

pub use read_fonts::FontRef;

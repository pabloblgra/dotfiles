# Project Maintainers

The intellectual property rights for `tiny-xlib` are owned by Project Leadership, which consists of the following structure:

## Benevolent Dictator for Life

- [John Nunley](https://github.com/notgull) is the Benevolent Dictator for Life (BDFL) of this project. He has the final say in project direction and disputes.

## Other Information

Members of Project Leadership may change in the future without license changes.

Contract project leadership at the email consisting of:

- The BDFL's first initial.
- The BDFL's middle initial.
- The BDFL's last name.
- The "at" sign.
- notgull dot net

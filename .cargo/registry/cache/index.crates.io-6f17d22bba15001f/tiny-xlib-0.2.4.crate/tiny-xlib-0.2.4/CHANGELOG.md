# Changelog

## v0.2.4

- Add `default_screen()` function for getting the index of the default screen. (#14)

## v0.2.3

- Replace `ctor` with `ctor-lite` to remove proc-macro dependencies. (#12)

## v0.2.2

Implement better loading on `dlopen` mode.

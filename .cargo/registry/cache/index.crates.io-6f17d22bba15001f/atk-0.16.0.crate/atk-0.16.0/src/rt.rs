// Take a look at the license at the top of the repository in the LICENSE file.

/// No-op.
macro_rules! assert_initialized_main_thread {
    () => {};
}

/// No-op.
macro_rules! skip_assert_initialized {
    () => {};
}

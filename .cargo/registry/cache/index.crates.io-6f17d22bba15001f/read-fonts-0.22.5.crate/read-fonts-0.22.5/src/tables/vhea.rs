//! the [vhea (Horizontal Header)](https://docs.microsoft.com/en-us/typography/opentype/spec/hhea) table

include!("../../generated/generated_vhea.rs");

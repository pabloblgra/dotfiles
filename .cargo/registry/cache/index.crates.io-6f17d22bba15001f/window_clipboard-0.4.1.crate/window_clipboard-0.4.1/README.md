# window_clipboard
[![Test Status](https://github.com/hecrj/window_clipboard/workflows/Test/badge.svg)](https://github.com/hecrj/window_clipboard/actions)
[![Documentation](https://docs.rs/window_clipboard/badge.svg)][documentation]
[![Crates.io](https://img.shields.io/crates/v/window_clipboard.svg)](https://crates.io/crates/window_clipboard)
[![License](https://img.shields.io/crates/l/window_clipboard.svg)](https://github.com/hecrj/window_clipboard/blob/master/LICENSE)

A library to obtain clipboard access from a `raw-window-handle`.

__Very experimental, use at your own risk!__

[documentation]: https://docs.rs/window_clipboard

# Hyprland Macros
Literally only async closure macro lol

This library is primarly distributed under the terms of both the MIT license and
the Apache License (Version 2.0).

See license-apache.md and license-mit.md for details.

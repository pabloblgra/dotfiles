// TODO: Fix the compiler error.
fn main() {
    let x = 3;
    println!("Number {x}");

    x = 5; // Don't change this line
    println!("Number {x}");
}

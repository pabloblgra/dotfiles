fn main() {
    // Declaring variables requires the `let` keyword.
    let x = 5;

    println!("x has the value {x}");
}

// Some function with the name `call_me` without arguments or a return value.
fn call_me() {
    println!("Hello world!");
}

fn main() {
    call_me();
}

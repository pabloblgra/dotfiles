#![allow(bad_style)]

include!("bindings.rs");

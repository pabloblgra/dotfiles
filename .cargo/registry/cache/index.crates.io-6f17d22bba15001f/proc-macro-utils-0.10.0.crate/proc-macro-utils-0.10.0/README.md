# proc-macro-utils

[![CI Status](https://github.com/ModProg/proc-macro-utils/actions/workflows/test.yaml/badge.svg)](https://github.com/ModProg/proc-macro-utils/actions/workflows/test.yaml)
[![Crates.io](https://img.shields.io/crates/v/proc-macro-utils)](https://crates.io/crates/proc-macro-utils)
[![Docs.rs](https://img.shields.io/crates/v/proc-macro-utils?color=informational&label=docs.rs)](https://docs.rs/proc-macro-utils)
[![Documentation for `main`](https://img.shields.io/badge/docs-main-informational)](https://modprog.github.io/proc-macro-utils/proc_macro_utils/)


Some utility functions on proc-macro types.

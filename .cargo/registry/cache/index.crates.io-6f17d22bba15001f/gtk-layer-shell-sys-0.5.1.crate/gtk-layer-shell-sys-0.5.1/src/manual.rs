use glib::gpointer;

pub type zwlr_layer_surface_v1 = gpointer;

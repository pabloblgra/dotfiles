# manyhow Macros

This crate provides the [`#[manyhow]`](https://docs.rs/manyhow/latest/manyhow/attr.manyhow.html) attribute macro.

# lyon::path

Path data structures and tools for vector graphics.

<p align="center">
  <a href="https://crates.io/crates/lyon_path">
      <img src="https://img.shields.io/crates/v/lyon_path.svg" alt="crates.io">
  </a>
  <a href="https://docs.rs/lyon_path">
      <img src="https://docs.rs/lyon_path/badge.svg" alt="documentation">
  </a>
</p>

`lyon_path` can be used as a standalone crate or as part of [lyon](https://docs.rs/lyon/) via the `lyon::path` module.


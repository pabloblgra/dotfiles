# Version 1.1.1

- Reimplement using 100% safe code. (#7)

# Version 1.1.0

- Make the crate `#![no_std]`.

# Version 1.0.0

- Initial version.

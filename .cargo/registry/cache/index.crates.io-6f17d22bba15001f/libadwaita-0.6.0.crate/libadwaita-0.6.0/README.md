# libadwaita-rs

The Rust bindings of [libadwaita](https://gitlab.gnome.org/GNOME/libadwaita)

Website: <https://world.pages.gitlab.gnome.org/Rust/libadwaita-rs>

## Documentation

- libadwaita: <https://world.pages.gitlab.gnome.org/Rust/libadwaita-rs/stable/latest/docs/libadwaita>
- libadwaita-sys: <https://world.pages.gitlab.gnome.org/Rust/libadwaita-rs/stable/latest/docs/libadwaita_sys>

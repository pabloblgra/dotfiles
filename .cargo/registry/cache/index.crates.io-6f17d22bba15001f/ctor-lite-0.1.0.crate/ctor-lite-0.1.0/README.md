# ctor-lite

The [`ctor`] crate rewritten using procedural macros.

## License

MIT/Apache2

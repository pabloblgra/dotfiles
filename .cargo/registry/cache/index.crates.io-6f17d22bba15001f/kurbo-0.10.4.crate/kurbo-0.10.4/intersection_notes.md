## References

[Complete Subdivision Algorithms, I: Intersection of Bezier Curves](https://cs.nyu.edu/exact/doc/subdiv1.pdf)


[Complete, exact, and efficient computations with cubic curves](https://dl.acm.org/doi/10.1145/997817.997879)


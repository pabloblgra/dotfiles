This looks state of the art:

https://cristiano-de-michele.netlify.app/publication/orellana-2020/orellana-2020.pd
f

References Strobach

Very rigorous bounds on computation on p^3 - q^2 (using FMA):

https://math.stackexchange.com/questions/2434354/numerically-stable-scheme-for-the-3-real-roots-of-a-cubic

https://momentsingraphics.de/FMA.html

explains Kahan's method

question: it's a call to fma on generic x86_64. How big a loss?


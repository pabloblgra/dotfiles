
# bytemuck_derive

Derive macros for [bytemuck](https://docs.rs/bytemuck) traits.

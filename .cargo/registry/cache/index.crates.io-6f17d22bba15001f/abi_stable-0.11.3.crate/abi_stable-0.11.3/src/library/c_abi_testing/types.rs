#[derive(Debug, StableAbi, Copy, Clone)]
#[repr(C)]
pub(crate) struct MyUnit;

// include!(concat!(env!("OUT_DIR"), "/skeptic-tests.rs"));

mod impl_interfacetype_attr;

mod impl_interfacetype_macro;

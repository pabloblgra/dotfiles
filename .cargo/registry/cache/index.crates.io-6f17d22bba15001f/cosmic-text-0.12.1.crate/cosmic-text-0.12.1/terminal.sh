RUST_LOG=cosmic_text=debug,terminal=debug cargo run --release --package terminal -- "$@"

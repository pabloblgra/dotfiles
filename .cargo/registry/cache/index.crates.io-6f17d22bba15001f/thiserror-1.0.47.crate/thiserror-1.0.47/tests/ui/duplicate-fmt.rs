use thiserror::Error;

#[derive(Error, Debug)]
#[error("...")]
#[error("...")]
pub struct Error;

fn main() {}

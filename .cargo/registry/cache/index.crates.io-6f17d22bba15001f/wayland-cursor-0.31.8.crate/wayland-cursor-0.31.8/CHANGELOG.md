# CHANGELOG: wayland-cursor

## Unreleased

## 0.31.3 -- 2024-05-30

#### Bugfixes
- Add `Send + Sync` bounds to fallback callback

## 0.31.2 -- 2024-05-30

### Additions
- Add `set_fallback` method

## 0.31.1 -- 2024-01-29

- Dropped `nix` dependency in favor or `rustix`

## 0.31.0 -- 2023-09-02

- Update to wayland-client 0.31

## 0.30.0 -- 27/12/2022

## 0.30.0-alpha1

Rework of the crate as a consequence of the rework of `wayland-client`.
